python3 -m build
cp -r dist/* ../cflab_amhs/computing/dist/